﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPI.Models
{
    public class Finances
    {
        public int FinanceId { get; set; }
        public string FinanceName { get; set; }
        public string Catorgies { get; set; }
        public string FinanceDate { get; set; }
        public int amount { get; set; }


    }
}