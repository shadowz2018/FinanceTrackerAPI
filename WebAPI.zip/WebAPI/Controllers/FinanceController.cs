﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web;

namespace WebAPI.Controllers
{
    public class FinanceController : ApiController
    {
        public HttpResponseMessage Get()
        {
            string query = @"
                    select FinanceId,FinanceName,Catorgies,
                    convert(varchar(10),FinanceDate,120) as FinanceDate,
                    amount
                    from
                    dbo.Finances
                    ";
            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["FinanceTrackerDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);


        }

        public string Post(Finances fin)
        {
            try
            {
                string query = @"
                    insert into dbo.Finance values
                    (
                    '" + fin.FinanceId + @"'
                    ,'" + fin.FinanceName + @"'
                    ,'" + fin.Catorgies + @"'
                    ,'" + fin.FinanceDate + @"'
                    '" + fin.amount + @"'
                    )
                    ";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["FinanceTrackerDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Added Successfully!!";
            }
            catch (Exception)
            {

                return "Failed to Add!!";
            }
        }


        public string Put(Finances fin)
        {
            try
            {
                string query = @"
                    update dbo.Finances set 
                    FinanceName='" + fin.FinanceName + @"'
                    ,Catorgies='" + fin.Catorgies + @"'
                    ,FinanceDate='" + fin.FinanceDate + @"'
                    ,amount='" + fin.amount + @"'
                    where FinanceId=" + fin.FinanceId + @"
                    ";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["FinanceTrackerDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Updated Successfully!!";
            }
            catch (Exception)
            {

                return "Failed to Update!!";
            }
        }


        public string Delete(int id)
        {
            try
            {
                string query = @"
                    delete from dbo.Finances 
                    where FinanceId=" + id + @"
                    ";

                DataTable table = new DataTable();
                using (var con = new SqlConnection(ConfigurationManager.
                    ConnectionStrings["FinanceTrackerDB"].ConnectionString))
                using (var cmd = new SqlCommand(query, con))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }

                return "Deleted Successfully!!";
            }
            catch (Exception)
            {

                return "Failed to Delete!!";
            }
        }
        [Route("api/Finances/GetAllCatorgyNames")]
        [HttpGet]
        public HttpResponseMessage GetAllCatorgyNames()
        {
            string query = @"
                    select CatorgyName from dbo.Catorgies";

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.
                ConnectionStrings["FinanceTrackerDB"].ConnectionString))
            using (var cmd = new SqlCommand(query, con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }

            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
    }
}
